
// h.cpp : Este archivo contiene la funci�n "main". La ejecuci�n del programa comienza y termina ah�.
//
#include "Usuario.h"
#include <string>
using namespace std;
//rafaela ribera
Usuario::Usuario(string _login, string _password)
{
	login = _login;
	password = _password;
}

bool Usuario::Verificarlogin(string _login, string _password) 
{

	bool aux = false;
	if ((login == _login) && (password == _password))
		aux = true;
		return aux;
}


