// h.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//
//Rafaela Ribera
#include <iostream>
#include "Usuario.h"

using namespace std;

int main()
{
	string usuario, contrasenia;
	Usuario usuario1("rafaelarv", "miconta");
	cout << "Ingresar usuario: ";
	cin >> usuario;
	cout << "Ingresar password: ";
	cin >> contrasenia;
	if (usuario1.Verificarlogin(usuario, contrasenia))
		cout << "Puedes pasar" << endl;
	else
		cout << "No puedes pasar ";

}